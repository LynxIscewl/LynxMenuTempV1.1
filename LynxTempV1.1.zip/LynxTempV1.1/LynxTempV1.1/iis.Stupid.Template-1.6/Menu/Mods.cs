﻿using System;
using System.Collections.Generic;
using System.Text;
using Photon.Pun;
using PlayFab.ClientModels;
using UnityEngine;
using UnityEngine.InputSystem;

namespace LynxMenuTemp.Menu
{
    class mods
    {

        public static void placeholder()
        {

        }

        public static void disconnect()
        {
            PhotonNetwork.Disconnect();
        }





    }
}
